from setuptools import setup

package_name = 'bic_package'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ubuntu',
    maintainer_email='ubuntu@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
        	'publisher = bic_package.bic_publisher:main',
        	'scanner = bic_package.input_node:main',
        	'actuator = bic_package.output_node:main',
        	'pose_publisher = bic_package.pose_publisher:main'
        ],
    },
)
